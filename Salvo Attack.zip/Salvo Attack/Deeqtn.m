function [Value,isTerminal,direction] = Deeqtn(t,X)
Value= X(1)-0.1;
isTerminal=1;
direction=0;
end